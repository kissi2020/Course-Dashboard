import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const CourseDashboardApp());

class CourseDashboardApp extends StatelessWidget {
  const CourseDashboardApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Course Dashboard',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2E7D32)),
        useMaterial3: true,
      ),
      home: const RootScaffold(),
    );
  }
}

class RootScaffold extends StatefulWidget {
  const RootScaffold({super.key});
  @override
  State<RootScaffold> createState() => _RootScaffoldState();
}

class _RootScaffoldState extends State<RootScaffold> {
  int _index = 0;
  final _titles = const ['Home', 'Courses', 'Profile'];

  @override
  Widget build(BuildContext context) {
    final tabs = [
      const HomeTab(),
      const CoursesTab(),
      ProfileTab(onLogout: () => _confirmExit(context)),
    ];

    return Scaffold(
      appBar: AppBar(title: Text(_titles[_index]), centerTitle: true),
      body: Column(
        children: [
          const SizedBox(height: 8),
          Text('Active Tab: ${_titles[_index]}',
              style: Theme.of(context).textTheme.titleLarge),
          const Divider(height: 16),
          Expanded(child: tabs[_index]),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        onTap: (i) => setState(() => _index = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.menu_book), label: 'Courses'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }

  Future<void> _confirmExit(BuildContext context) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Confirm Logout'),
        content: const Text('Are you sure you want to exit the app?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('No')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Yes')),
        ],
      ),
    );
    if (ok == true) {
      SystemNavigator.pop(); // Exit app on Android
    }
  }
}

class HomeTab extends StatelessWidget {
  const HomeTab({super.key});
  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Text(
          'Welcome to the Course Dashboard.\nUse the tabs below to explore.',
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}

class CoursesTab extends StatefulWidget {
  const CoursesTab({super.key});
  @override
  State<CoursesTab> createState() => _CoursesTabState();
}

class _CoursesTabState extends State<CoursesTab> {
  final _categories = const ['Science', 'Arts', 'Technology', 'Business', 'Health'];
  String _selectedCategory = 'Technology';
  bool _enrolled = false;

  final _courses = const [
    ('Mobile App Dev', 'Mr. Emmanuel Botchway', Icons.phone_android),
    ('Infornation Security', 'Mr. Jacob Mensah', Icons.hub),
    ('Project Management', 'Dr. Kwabena Adu', Icons.router),
    ('Research Management', 'Dr. K Dorson', Icons.storage),
    ('Operating Systems', 'Dr. Asare', Icons.memory),
    ('Advance Web Engineering', 'Ms. Adjei', Icons.web),
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // (e) Course Selection Dropdown
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: DropdownButtonFormField<String>(
            value: _selectedCategory,
            items: _categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _selectedCategory = v!),
            decoration: const InputDecoration(
              labelText: 'Select Course Category',
              border: OutlineInputBorder(),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Align(
            alignment: Alignment.centerLeft,
            child: Text('Selected: $_selectedCategory'),
          ),
        ),
        const SizedBox(height: 8),

        // (a) Course List View (5+ items)
        Expanded(
          child: ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: _courses.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, i) {
              final (name, instructor, icon) = _courses[i];
              return ListTile(
                tileColor: Theme.of(context).colorScheme.surfaceVariant.withOpacity(.5),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                leading: CircleAvatar(child: Icon(icon)),
                title: Text(name),
                subtitle: Text('Instructor: $instructor'),
                trailing: const Icon(Icons.chevron_right),
              );
            },
          ),
        ),

        // (d) Animated Action Button
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          child: GestureDetector(
            onTap: () => setState(() => _enrolled = !_enrolled),
            child: AnimatedScale(
              scale: _enrolled ? 1.15 : 1.0,
              duration: const Duration(milliseconds: 250),
              child: FilledButton.icon(
                onPressed: null, // GestureDetector handles the tap for animation
                icon: const Icon(Icons.school),
                label: Text(_enrolled ? 'Enrolled' : 'Enroll in a course'),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class ProfileTab extends StatelessWidget {
  final VoidCallback onLogout;
  const ProfileTab({super.key, required this.onLogout});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: ListTile(
            leading: const Icon(Icons.logout),
            title: const Text('Logout'),
            subtitle: const Text('Tap to exit the app with confirmation'),
            onTap: onLogout, // (c) Exit Confirmation Dialog
          ),
        ),
        const SizedBox(height: 12),
        const Card(
          child: ListTile(
            leading: Icon(Icons.info_outline),
            title: Text('About'),
            subtitle: Text('Course Dashboard App'),
          ),
        ),
      ],
    );
  }
}
